const toggle = document.getElementById('themeToggle');
toggle.onclick = () => {
  document.body.classList.toggle('light');
};
